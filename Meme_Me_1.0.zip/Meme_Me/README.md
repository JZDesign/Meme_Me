# Meme_Me


Meme Generator with optional settings to change background color and font type using a delegate to call data back from a segue.
